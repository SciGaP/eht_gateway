while IFS= read -r filename; do
    touch "$filename"
    echo "Created file: $filename"
done < "test1.txt"
