for f in *.ALL; do sed -i 's/home\/cicuser/ospool\/uc-shared\/public\/eht/g' "$f"; done
