# dataset_parser.py
# parse listing.txt 

import os
import sys
import json

v = {}
v['data_collection'] = "GRMHD_kharma-v3"
v['storage_type'] = "OSDF"
v['storage_location'] = "ap21:/ospool/uc-shared/public/eht/GRMHD_kharma-v3"

listing = "listing.txt"

with open(listing,'r') as f:
    lines = [line.rstrip() for line in f]

print("Total lines:",len(lines))

# find unique folder name
folders = [x.split("/")[1] for x in lines]
folders = set(folders)
print("folders: ", len(folders))
print(folders)

# data folder begin with Ma
# parameter file in ./rho0/rho0_Ma+0.94.tsv
datafolder = [x for x in folders if "Ma" in x]
print("datafolder: ",datafolder)

rhos = [line.split("/")[-1] for line in lines if "./rho0/rho0" in line]
print(rhos)

dataset_list = []
for item in datafolder:
    vd = {}
    # pick up h5 file without folder name
    h5s = [line.split("/")[-1] for line in lines if ((item in line) and (".h5" in line) )]
    print(item,":",len(h5s))
    # write file names to a file
    out_file = item + ".txt"
    vd['dataset'] = item
    vd['size'] = len(h5s)
    vd['h5_list'] = out_file
    # find parafile
    basename = item.split("_")[0]
    parafile = [x for x in rhos if basename in x]
    vd['rho0'] = parafile[0]
    vd["BATCH"] = item + "_BATCH.ALL"
    vd["BATCH_size"] = 36000
    dataset_list.append(vd)
    if not os.path.exists(out_file):
        print("write file list to: ", out_file)
        with open(out_file,"w") as f:
            f.write("\n".join(h5s))
print(dataset_list)

v['datasets'] = dataset_list

jsonname = v['data_collection']+".json"
# dump v file as json file
with open(jsonname, 'w') as fp:
    json.dump(v, fp, indent=4)

sys.exit()

# prepare run pragen to generate BATCH.ALL

# generate empty file in local folder
print("config local data folder")
localfolder = os.path.expanduser("~/" + v['data_collection'])
emptyfile_counter = 0
for item in dataset_list:
    print(item['dataset'])
    subfolder = os.path.join(localfolder,item['dataset'])
    if not os.path.exists(subfolder):
        print("create ", subfolder)
        os.makedirs(subfolder,exist_ok=True)
    
    # generate the empty file
    with open(item['h5_list'],'r') as f:
        lines = [line.rstrip() for line in f]
    
    h5s = [line for line in lines if (".h5" in line)]
    # create empty file
    for h5 in h5s:
        emptyfile = os.path.join(subfolder, h5)
        if not os.path.exists(emptyfile):
            os.system(f"touch {emptyfile}")
            emptyfile_counter += 1

print("empty file created: ", emptyfile_counter)

# run pragen
print("run pargen")
template_job = os.path.join(localfolder, "template_job")
pre_config = os.path.join(localfolder, "preconfig")
for item in dataset_list:
    print(item['dataset'])
    jobfolder = os.path.expanduser(f"~/{item['dataset']}")
    os.system(f"cp -pr {template_job} {jobfolder}")
    os.chdir(jobfolder)
    if not os.path.exists("par/BATCH.ALL"):
        os.system("bin/pargen > par/BATCH.ALL")
    # copy batch all
    pre_batch = os.path.join(pre_config,item['dataset']+"_"+"BATCH.ALL")
    print("copy: ", pre_batch)
    os.system(f"cp par/BATCH.ALL {pre_batch}")

# need to replace path in pargen
# sed -i 's/home\/ehtbot/ospool\/uc-shared\/public\/eht/g' BATCH.ALL

# run sed to update path
